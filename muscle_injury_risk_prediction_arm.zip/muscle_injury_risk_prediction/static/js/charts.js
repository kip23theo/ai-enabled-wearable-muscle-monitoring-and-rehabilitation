/* charts.js - rehabilitation graphs (Chart.js).
   p = { sessions: [...], target: number, labels: {joint, lower, upper} }  (same shape as build_progress() in app.py) */
window.RehabCharts = (function () {
  const TEAL = '#0f8b8d', BLUE = '#2f6fdb', RED = '#d8453b', GRAY = '#8a99a3', AMBER = '#e0a020';
  const css = (n) => getComputedStyle(document.documentElement).getPropertyValue(n).trim();

  function theme() {
    Chart.defaults.color = css('--muted') || '#5b707a';
    Chart.defaults.borderColor = css('--line') || '#d4e0e4';
    Chart.defaults.font.family = getComputedStyle(document.body).fontFamily;
  }

  const labels = (p) => p.sessions.map((s) => '#' + s.n);
  const J = (p) => (p.labels && p.labels.joint) || 'Elbow';
  const title = (p) => (items) => {
    const s = p.sessions[items[0].dataIndex];
    return s ? 'Session ' + s.n + ' · ' + s.date + ' ' + s.time : '';
  };

  function base(p, yTitle) {
    return {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: { position: 'bottom', labels: { boxWidth: 12 } },
        tooltip: { callbacks: { title: title(p) } },
      },
      scales: {
        x: { grid: { display: false }, title: { display: true, text: 'Session' } },
        y: { title: { display: true, text: yTitle || 'Degrees' } },
      },
    };
  }

  // ROM per session vs target. `highlightId` enlarges one point (e.g. the session just finished)
  function rom(canvas, p, highlightId) {
    theme();
    const radius = p.sessions.map((s) => (s.id === highlightId ? 8 : 4));
    const opts = base(p, J(p) + ' range of motion (°)');
    opts.scales.y.beginAtZero = true;
    opts.scales.y.suggestedMax = Math.ceil(p.target * 1.1);
    return new Chart(canvas, {
      type: 'line',
      data: {
        labels: labels(p),
        datasets: [
          { label: J(p) + ' ROM', data: p.sessions.map((s) => s.rom), borderColor: TEAL,
            backgroundColor: TEAL + '30', fill: true, tension: 0.25, borderWidth: 3,
            pointRadius: radius, pointBackgroundColor: TEAL },
          { label: 'Target ROM', data: p.sessions.map(() => p.target), borderColor: GRAY,
            borderDash: [6, 4], borderWidth: 2, pointRadius: 0, fill: false },
        ],
      },
      options: opts,
    });
  }

  // Min and max elbow angle reached in each session (band = range)
  function minmax(canvas, p) {
    theme();
    return new Chart(canvas, {
      type: 'line',
      data: {
        labels: labels(p),
        datasets: [
          { label: 'Min angle', data: p.sessions.map((s) => s.elbow_min), borderColor: BLUE,
            tension: 0.25, borderWidth: 2.5, pointRadius: 4, pointBackgroundColor: BLUE, fill: false },
          { label: 'Max angle', data: p.sessions.map((s) => s.elbow_max), borderColor: TEAL,
            backgroundColor: TEAL + '28', tension: 0.25, borderWidth: 2.5, pointRadius: 4,
            pointBackgroundColor: TEAL, fill: '-1' },
        ],
      },
      options: base(p, J(p) + ' angle (°)'),
    });
  }

  // Pain level (bars, right axis) against ROM (line, left axis)
  function painRom(canvas, p) {
    theme();
    const opts = base(p, J(p) + ' ROM (°)');
    opts.scales.y.beginAtZero = true;
    opts.scales.y1 = {
      position: 'right', min: 0, max: 10, grid: { drawOnChartArea: false },
      title: { display: true, text: 'Pain (0-10)' },
    };
    return new Chart(canvas, {
      data: {
        labels: labels(p),
        datasets: [
          { type: 'bar', label: 'Pain level', data: p.sessions.map((s) => s.pain), yAxisID: 'y1',
            backgroundColor: RED + '66', borderRadius: 4, order: 2 },
          { type: 'line', label: J(p) + ' ROM', data: p.sessions.map((s) => s.rom), yAxisID: 'y',
            borderColor: TEAL, borderWidth: 3, tension: 0.25, pointRadius: 4,
            pointBackgroundColor: TEAL, order: 1 },
        ],
      },
      options: opts,
    });
  }

  // Repetitions per session
  function reps(canvas, p) {
    theme();
    const opts = base(p, 'Repetitions');
    opts.scales.y.beginAtZero = true;
    opts.scales.y.ticks = { precision: 0 };
    return new Chart(canvas, {
      type: 'bar',
      data: {
        labels: labels(p),
        datasets: [{ label: 'Repetitions', data: p.sessions.map((s) => s.reps),
          backgroundColor: AMBER + 'aa', borderRadius: 4 }],
      },
      options: opts,
    });
  }

  // Angles over time inside one session. samples = [[t, bicep, forearm, elbow], ...]
  function series(canvas, samples, s, L) {
    theme();
    L = L || { joint: 'Elbow', lower: 'Forearm', upper: 'Upper arm' };
    const pts = (i) => samples.map((r) => ({ x: r[0], y: r[i] }));
    const tEnd = samples.length ? samples[samples.length - 1][0] : 1;
    const line = (label, y, color) => ({
      label: label, data: [{ x: 0, y: y }, { x: tEnd, y: y }], borderColor: color,
      borderDash: [5, 4], borderWidth: 1.5, pointRadius: 0, fill: false,
    });
    return new Chart(canvas, {
      type: 'line',
      data: {
        datasets: [
          { label: L.joint + ' angle', data: pts(3), borderColor: TEAL, borderWidth: 2.5, pointRadius: 0, tension: 0.2, parsing: false },
          { label: L.lower, data: pts(2), borderColor: BLUE, borderWidth: 1.5, pointRadius: 0, tension: 0.2, parsing: false },
          { label: L.upper, data: pts(1), borderColor: AMBER, borderWidth: 1.5, pointRadius: 0, tension: 0.2, parsing: false },
          line(L.joint + ' max', s.elbow_max, TEAL),
          line(L.joint + ' min', s.elbow_min, GRAY),
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: { mode: 'nearest', intersect: false },
        plugins: { legend: { position: 'bottom', labels: { boxWidth: 12 } } },
        scales: {
          x: { type: 'linear', title: { display: true, text: 'Time (seconds)' } },
          y: { title: { display: true, text: 'Angle (°)' } },
        },
      },
    });
  }

  // Average + peak EMG per session, with the strength-band guide lines
  function emg(canvas, p, bands) {
    theme();
    const guide = (label, y) => ({ type: 'line', label: label, data: p.sessions.map(() => y), borderColor: GRAY,
      borderDash: [4, 4], borderWidth: 1.2, pointRadius: 0, fill: false, order: 5 });
    const opts = base(p, 'EMG value (0-4095)');
    opts.scales.y.beginAtZero = true;
    opts.scales.y.suggestedMax = 4095;
    return new Chart(canvas, {
      data: {
        labels: labels(p),
        datasets: [
          { type: 'bar', label: 'Average EMG', data: p.sessions.map((s) => s.emg_avg), backgroundColor: TEAL + '99', borderRadius: 4, order: 3 },
          { type: 'line', label: 'Peak EMG', data: p.sessions.map((s) => s.emg_max), borderColor: RED, borderWidth: 2.5,
            tension: 0.25, pointRadius: 4, pointBackgroundColor: RED, order: 1 },
          guide('Moderate from ' + bands.low, bands.low),
          guide('High from ' + bands.mod, bands.mod),
        ],
      },
      options: opts,
    });
  }

  // EMG over time inside one session. samples = [[t, bicep, forearm, elbow, emg], ...]
  function emgSeries(canvas, samples, bands) {
    theme();
    const pts = samples.filter((r) => r[4] !== null && r[4] !== undefined).map((r) => ({ x: r[0], y: r[4] }));
    const tEnd = pts.length ? pts[pts.length - 1].x : 1;
    const guide = (label, y) => ({ label: label, data: [{ x: 0, y: y }, { x: tEnd, y: y }], borderColor: GRAY,
      borderDash: [4, 4], borderWidth: 1.2, pointRadius: 0, fill: false });
    return new Chart(canvas, {
      type: 'line',
      data: { datasets: [
        { label: 'EMG', data: pts, borderColor: RED, backgroundColor: RED + '22', fill: true, borderWidth: 2, pointRadius: 0, tension: 0.2, parsing: false },
        guide('Moderate from ' + bands.low, bands.low),
        guide('High from ' + bands.mod, bands.mod),
      ] },
      options: {
        responsive: true, maintainAspectRatio: false, interaction: { mode: 'nearest', intersect: false },
        plugins: { legend: { position: 'bottom', labels: { boxWidth: 12 } } },
        scales: {
          x: { type: 'linear', title: { display: true, text: 'Time (seconds)' } },
          y: { beginAtZero: true, suggestedMax: 4095, title: { display: true, text: 'EMG value' } },
        },
      },
    });
  }

  return { rom: rom, minmax: minmax, painRom: painRom, reps: reps, series: series, emg: emg, emgSeries: emgSeries };
})();
