/* arm3d.js - 3D arm with muscles (three.js) for the arm curl exercise.

   One arm only: shoulder (deltoid), upper arm (biceps brachii long + short head, brachialis,
   triceps), elbow, forearm (brachioradialis, flexors, extensors), wrist and hand. Bones and
   tendons are drawn too. The tendons that cross the elbow are re-stretched on every pose
   update, so they stay attached while the elbow bends.

   Units: 1 unit ~ 7.5 cm. The arm hangs down -Y from the shoulder, the front of the body is +X,
   the outer (lateral) side of a RIGHT arm is +Z (towards the default camera).

   The EMG muscle strength drives the biceps (fully), brachialis and brachioradialis (partly):
   the muscle belly turns from relaxed pink to glowing red and thickens a little.

   window.Arm3D = { setSide('right'|'left'), setPose(upperDeg, lowerDeg), setMuscle(0..1),
                    setSkin(bool), goView(name), controls, pivot } */
window.Arm3D = (function () {
  // ---- Dimensions (same arm lengths as hand_new.py) ----
  const UPPER = 4.0, FORE = 3.5;
  const SH_Y = 6.0;                              // shoulder height above the grid
  const BONE = 0xe9e1cf, TENDON = 0xf1e8d2;
  const SKIN = 0xe3ae8f, NAIL = 0xf4d9cc, HAND_MUSCLE = 0xc9786c;
  const ACCENT = 0x1fb5b7;
  const rad = THREE.MathUtils.degToRad;

  // ---- Scene ----
  const stage = document.getElementById('stage');
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(45, 1, 0.1, 300);
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.outputEncoding = THREE.sRGBEncoding;
  stage.appendChild(renderer.domElement);

  scene.add(new THREE.HemisphereLight(0xffffff, 0x8a98a3, 0.8));
  const key = new THREE.DirectionalLight(0xfff3e8, 0.9);
  key.position.set(10, 20, 16);
  scene.add(key);
  const fill = new THREE.DirectionalLight(0xdde8ff, 0.4);
  fill.position.set(-12, 6, 8);
  scene.add(fill);
  const rim = new THREE.DirectionalLight(0xffffff, 0.35);
  rim.position.set(-4, 8, -16);
  scene.add(rim);

  const grid = new THREE.GridHelper(44, 44, 0x7f93a0, 0xa9b8c1);
  grid.position.y = -3.7;                        // just under the fingertips of a hanging arm
  grid.material.transparent = true;
  grid.material.opacity = 0.4;
  scene.add(grid);

  const pivot = new THREE.Group();               // "Rotate arm" slider spins this about the vertical axis
  pivot.position.set(0, SH_Y, 0);                // ... through the shoulder
  scene.add(pivot);
  const armRoot = new THREE.Group();             // scale.z = -1 turns the right arm into a left arm
  pivot.add(armRoot);
  const shoulder = new THREE.Group();            // origin = shoulder joint, rotates with the upper arm
  armRoot.add(shoulder);
  const elbow = new THREE.Group();               // origin = elbow joint, rotates with the forearm
  elbow.position.y = -UPPER;
  shoulder.add(elbow);
  const wrist = new THREE.Group();
  wrist.position.y = -FORE;
  elbow.add(wrist);

  // ---- Materials / helpers ----
  function fibreTexture(base, light, dark, seed) {
    // Lengthwise muscle fibres: random light/dark stripes. LatheGeometry's u runs around the
    // belly, so vertical stripes in this image become fibres along the muscle.
    const c = document.createElement('canvas');
    c.width = 256; c.height = 32;
    const g = c.getContext('2d');
    g.fillStyle = base;
    g.fillRect(0, 0, 256, 32);
    let k = seed || 7;
    const rnd = () => { k = (k * 16807) % 2147483647; return k / 2147483647; };
    for (let x = 0; x < 256;) {
      const w = 1 + rnd() * 3.5, a = rnd();
      g.globalAlpha = 0.25 + rnd() * 0.45;
      g.fillStyle = a < 0.4 ? light : (a < 0.75 ? dark : base);
      g.fillRect(x, 0, w, 32);
      x += w;
    }
    g.globalAlpha = 1;
    const t = new THREE.CanvasTexture(c);
    t.wrapS = THREE.RepeatWrapping;
    t.repeat.set(2, 1);
    t.encoding = THREE.sRGBEncoding;
    return t;
  }
  const TEX_RED = fibreTexture('#b24a40', '#d4766a', '#7d2b27', 11);
  const TEX_DEEP = fibreTexture('#a24037', '#c8685c', '#702623', 23);

  function std(color, rough, extra) {
    return new THREE.MeshStandardMaterial(Object.assign({ color: color, roughness: rough === undefined ? 0.7 : rough, metalness: 0 }, extra || {}));
  }
  function muscleMat(tint, tex) {
    const m = new THREE.MeshStandardMaterial({ map: tex, color: tint, roughness: 0.5, metalness: 0, emissive: 0x000000 });
    m.side = THREE.DoubleSide;
    return m;
  }
  const boneMat = std(BONE, 0.55);
  const tendonMat = std(TENDON, 0.45);

  // Fusiform muscle belly hanging down -Y from the origin: `len` long, `r` thick at its widest,
  // fattest at `peak` (0..1 of the length).
  function bellyGeometry(len, r, peak) {
    const pts = [], N = 24;
    for (let i = 0; i <= N; i++) {
      const t = i / N;
      const k = t < peak ? t / peak : (1 - t) / (1 - peak);
      pts.push(new THREE.Vector2(Math.max(0.025, r * Math.pow(Math.sin(Math.PI / 2 * k), 0.75)), -len * t));
    }
    return new THREE.LatheGeometry(pts, 32);
  }

  const muscles = [];                            // { mesh, mat, w: glow weight, sx, sz }
  function addMuscle(parent, o) {
    const mat = muscleMat(o.tint === undefined ? 0xffffff : o.tint, o.tex || TEX_RED);
    const mesh = new THREE.Mesh(bellyGeometry(o.len, o.r, o.peak), mat);
    const sx = o.sx || 1, sz = o.sz || 1;
    mesh.scale.set(sx, 1, sz);
    mesh.position.set(o.x, o.y, o.z);
    if (o.rotZ) mesh.rotation.z = o.rotZ;
    parent.add(mesh);
    muscles.push({ mesh: mesh, mat: mat, w: o.w || 0, sx: sx, sz: sz });
    return mesh;
  }
  function sphere(r, mat, sx, sy, sz) {
    const m = new THREE.Mesh(new THREE.SphereGeometry(r, 24, 16), mat);
    m.scale.set(sx || 1, sy || 1, sz || 1);
    return m;
  }
  function cylinder(r, h, mat) {
    return new THREE.Mesh(new THREE.CylinderGeometry(r, r, h, 12, 1), mat);
  }

  // A thin cylinder stretched between two points (in the parent's frame)
  const UP = new THREE.Vector3(0, 1, 0), dir = new THREE.Vector3();
  function setSegment(mesh, a, b) {
    dir.subVectors(b, a);
    const len = Math.max(dir.length(), 1e-4);
    mesh.position.addVectors(a, b).multiplyScalar(0.5);
    mesh.scale.set(1, len, 1);
    mesh.quaternion.setFromUnitVectors(UP, dir.normalize());
  }
  function fixedTendon(parent, r, a, b) {
    const m = cylinder(r, 1, tendonMat);
    setSegment(m, new THREE.Vector3(a[0], a[1], a[2]), new THREE.Vector3(b[0], b[1], b[2]));
    parent.add(m);
    return m;
  }
  // Tendon that starts on the upper arm (shoulder frame) and ends on the forearm (elbow frame):
  // re-stretched whenever the elbow angle changes.
  const links = [];
  function crossTendon(r, a, bElbow) {
    const m = cylinder(r, 1, tendonMat);
    shoulder.add(m);
    links.push({ mesh: m, a: new THREE.Vector3(a[0], a[1], a[2]), b: new THREE.Vector3(bElbow[0], bElbow[1], bElbow[2]) });
    return m;
  }
  const tmpB = new THREE.Vector3();
  function updateLinks(relRad) {
    const c = Math.cos(relRad), s = Math.sin(relRad);
    links.forEach((l) => {
      tmpB.set(l.b.x * c - l.b.y * s, l.b.x * s + l.b.y * c - UPPER, l.b.z);   // elbow frame -> shoulder frame
      setSegment(l.mesh, l.a, tmpB);
    });
  }

  // ---------------- Bones ----------------
  const humerus = cylinder(0.13, UPPER, boneMat);
  humerus.position.y = -UPPER / 2;
  shoulder.add(humerus);
  shoulder.add(sphere(0.30, boneMat));                                   // head of the humerus
  const acromion = sphere(0.5, boneMat, 0.9, 0.18, 0.7);
  acromion.position.set(-0.15, 0.5, 0.0);
  shoulder.add(acromion);
  [[0, 0.05, 0.40], [0, 0.05, -0.40]].forEach((p) => {                  // epicondyles
    const e = sphere(0.17, boneMat);
    e.position.set(p[0], p[1], p[2]);
    elbow.add(e);
  });
  const olecranon = sphere(0.2, boneMat, 1, 1.1, 1);
  olecranon.position.set(-0.30, 0.0, 0);
  elbow.add(olecranon);
  const radius = cylinder(0.08, FORE - 0.1, boneMat);
  radius.position.set(0.06, -FORE / 2, 0.10);
  elbow.add(radius);
  const ulna = cylinder(0.09, FORE - 0.1, boneMat);
  ulna.position.set(-0.06, -FORE / 2, -0.06);
  elbow.add(ulna);
  const carpus = sphere(0.24, boneMat, 1, 0.7, 0.85);
  wrist.add(carpus);

  // ---------------- Upper arm muscles (shoulder frame) ----------------
  addMuscle(shoulder, { len: 2.1, r: 0.66, peak: 0.30, x: -0.02, y: 0.42, z: 0.08, tint: 0xf0d2cb, tex: TEX_DEEP });   // deltoid
  const deltoidCap = new THREE.Mesh(new THREE.SphereGeometry(0.58, 28, 18), muscleMat(0xf0d2cb, TEX_DEEP));       // rounds the top of the shoulder
  deltoidCap.scale.set(1.0, 0.82, 1.0);
  deltoidCap.position.set(-0.02, 0.2, 0.08);
  shoulder.add(deltoidCap);
  addMuscle(shoulder, { len: 3.05, r: 0.30, peak: 0.42, x: 0.20, y: -0.45, z: 0.13, w: 1.0 });                      // biceps, long head
  addMuscle(shoulder, { len: 2.85, r: 0.27, peak: 0.40, x: 0.22, y: -0.50, z: -0.12, w: 1.0 });                     // biceps, short head
  addMuscle(shoulder, { len: 2.30, r: 0.27, peak: 0.45, x: 0.10, y: -1.55, z: 0.20, sx: 0.8, w: 0.55, tex: TEX_DEEP }); // brachialis
  addMuscle(shoulder, { len: 3.00, r: 0.31, peak: 0.40, x: -0.22, y: -0.35, z: -0.04, tint: 0xe6c3bb, tex: TEX_DEEP }); // triceps, long head
  addMuscle(shoulder, { len: 2.50, r: 0.25, peak: 0.35, x: -0.10, y: -0.80, z: 0.28, tint: 0xe6c3bb, tex: TEX_DEEP }); // triceps, lateral head

  // Tendons of the upper arm muscles
  crossTendon(0.07, [0.25, -3.40, 0.0], [0.18, -0.55, 0.05]);            // biceps -> radial tuberosity
  crossTendon(0.06, [0.12, -3.80, 0.15], [0.20, -0.30, 0.0]);            // brachialis -> ulna
  crossTendon(0.09, [-0.24, -3.30, 0.0], [-0.30, 0.02, 0.0]);            // triceps -> olecranon
  fixedTendon(shoulder, 0.06, [0.20, -0.45, 0.10], [0.0, 0.1, 0.05]);    // biceps long head origin

  // EMG electrode pad on the biceps belly
  const pad = new THREE.Group();
  const padDisc = cylinder(0.17, 0.04, std(0xdfe6ea, 0.4));
  padDisc.rotation.z = Math.PI / 2;
  pad.add(padDisc);
  const padDot = cylinder(0.06, 0.06, std(ACCENT, 0.3, { emissive: ACCENT, emissiveIntensity: 0.5 }));
  padDot.rotation.z = Math.PI / 2;
  pad.add(padDot);
  pad.position.set(0.56, -1.85, 0.02);
  shoulder.add(pad);

  // ---------------- Forearm muscles (elbow frame) ----------------
  addMuscle(elbow, { len: 2.40, r: 0.21, peak: 0.20, x: 0.16, y: -0.15, z: 0.30, w: 0.45, tex: TEX_DEEP });          // brachioradialis
  addMuscle(elbow, { len: 2.60, r: 0.24, peak: 0.25, x: 0.22, y: -0.12, z: -0.04, tint: 0xe8c7bf, tex: TEX_DEEP });  // pronator teres / flexor carpi radialis
  addMuscle(elbow, { len: 2.70, r: 0.20, peak: 0.22, x: 0.04, y: -0.14, z: -0.28, tint: 0xe8c7bf, tex: TEX_DEEP });  // flexor carpi ulnaris
  addMuscle(elbow, { len: 2.50, r: 0.23, peak: 0.25, x: -0.20, y: -0.18, z: 0.14, tint: 0xe3bdb4, tex: TEX_DEEP });  // extensor group
  addMuscle(elbow, { len: 2.50, r: 0.17, peak: 0.28, x: -0.18, y: -0.18, z: -0.17, tint: 0xe3bdb4, tex: TEX_DEEP }); // extensor carpi ulnaris
  crossTendon(0.06, [0.05, -3.0, 0.32], [0.16, -0.15, 0.30]);            // brachioradialis origin on the humerus
  // forearm tendons run from the end of each belly to the wrist
  [[0.14, -2.45, 0.28], [0.20, -2.70, -0.04], [0.03, -2.80, -0.27], [-0.18, -2.62, 0.14], [-0.16, -2.62, -0.17]].forEach((p) => {
    fixedTendon(elbow, 0.05, p, [p[0] * 0.35, -FORE + 0.05, p[2] * 0.45]);
  });

  // ---------------- Hand (palm faces +X on the right arm, fingers hang down) ----------------
  const handMat = std(HAND_MUSCLE, 0.65);
  const nailMat = std(NAIL, 0.35);
  function buildHand() {
    // Palm faces +Z, back of hand (with nails) faces -Z, thumb on the -X side (before rotating).
    const handG = new THREE.Group();
    const palmShape = new THREE.Shape();
    palmShape.moveTo(-0.36, 0);
    palmShape.lineTo(0.36, 0);
    palmShape.bezierCurveTo(0.50, -0.40, 0.62, -0.80, 0.58, -1.12);
    palmShape.quadraticCurveTo(0.57, -1.22, 0.47, -1.22);
    palmShape.lineTo(-0.47, -1.22);
    palmShape.quadraticCurveTo(-0.57, -1.22, -0.58, -1.12);
    palmShape.bezierCurveTo(-0.62, -0.80, -0.52, -0.40, -0.36, 0);
    const pg = new THREE.ExtrudeGeometry(palmShape, {
      depth: 0.16, bevelEnabled: true, bevelThickness: 0.10, bevelSize: 0.08, bevelSegments: 6, curveSegments: 18
    });
    pg.translate(0, 0, -0.08);
    handG.add(new THREE.Mesh(pg, handMat));

    const thenar = sphere(1, handMat, 0.30, 0.46, 0.17);
    thenar.position.set(-0.30, -0.52, 0.15);
    thenar.rotation.z = 0.25;
    handG.add(thenar);

    function phalanx(len, rTop, rBot, isTip) {
      const g = new THREE.Group();
      const body = new THREE.Mesh(new THREE.CylinderGeometry(rTop, rBot, len, 18, 1), handMat);
      body.position.y = -len / 2;
      g.add(body);
      g.add(sphere(rTop, handMat));
      if (isTip) {
        const tip = sphere(rBot, handMat);
        tip.position.y = -len;
        g.add(tip);
        const nail = sphere(1, nailMat, rBot * 0.72, len * 0.32, rBot * 0.28);
        nail.position.set(0, -len * 0.72, -rBot * 0.82);
        g.add(nail);
      }
      return g;
    }
    function chain(lens, r, curl) {                  // curl[i] bends joint i toward the palm (+Z)
      const root = new THREE.Group();
      let parent = root, radius = r;
      lens.forEach((len, i) => {
        const rBot = radius * 0.84;
        const seg = phalanx(len, radius, rBot, i === lens.length - 1);
        if (i > 0) seg.position.y = -lens[i - 1];
        seg.rotation.x = curl[i];
        parent.add(seg);
        parent = seg;
        radius = rBot;
      });
      return root;
    }
    [
      { x: -0.44, lens: [0.46, 0.34, 0.26], r: 0.105, curl: [-0.10, -0.30, -0.22], splay: -0.07 },
      { x: -0.15, lens: [0.52, 0.40, 0.28], r: 0.112, curl: [-0.14, -0.34, -0.24], splay: -0.01 },
      { x: 0.15, lens: [0.48, 0.37, 0.27], r: 0.104, curl: [-0.18, -0.38, -0.26], splay: 0.04 },
      { x: 0.44, lens: [0.38, 0.28, 0.23], r: 0.088, curl: [-0.24, -0.40, -0.28], splay: 0.12 },
    ].forEach((f) => {
      const c = chain(f.lens, f.r, f.curl);
      c.position.set(f.x, -1.20, 0);
      c.rotation.z = f.splay;
      handG.add(c);
    });
    const thumb = chain([0.50, 0.42, 0.34], 0.135, [-0.15, -0.22, -0.30]);
    thumb.position.set(-0.46, -0.34, 0.06);
    thumb.rotation.z = -0.78;
    thumb.rotation.x = -0.28;
    handG.add(thumb);
    return handG;
  }
  const hand = buildHand();
  hand.rotation.y = Math.PI / 2;                   // palm forward (supinated), thumb on the outer side
  wrist.add(hand);

  // ---------------- Skin overlay (optional) + elbow marker ----------------
  const bicepR = (t) => 0.52 + 0.10 * Math.sin(Math.PI * Math.min(1, t * 1.15)) - 0.08 * t;
  const forearmR = (t) => 0.46 - 0.12 * t + 0.07 * Math.sin(Math.PI * Math.min(1, t * 1.4) * 0.9);
  function skinLathe(length, fn, extra) {
    const pts = [];
    for (let i = 0; i <= 30; i++) { const t = i / 30; pts.push(new THREE.Vector2(fn(t) + extra, -length * t)); }
    const m = new THREE.Mesh(new THREE.LatheGeometry(pts, 40), std(SKIN, 0.8, { transparent: true, opacity: 0.3, depthWrite: false }));
    return m;
  }
  const skinParts = [skinLathe(UPPER, bicepR, 0.08), skinLathe(FORE, forearmR, 0.07), sphere(0.8, std(SKIN, 0.8, { transparent: true, opacity: 0.3, depthWrite: false }), 1, 0.9, 1)];
  shoulder.add(skinParts[0]);
  elbow.add(skinParts[1]);
  skinParts[2].position.set(0, 0.1, 0.05);
  shoulder.add(skinParts[2]);
  skinParts.forEach((p) => { p.visible = false; });

  const marker = new THREE.Mesh(new THREE.TorusGeometry(0.62, 0.05, 10, 40),
    std(ACCENT, 0.4, { emissive: ACCENT, emissiveIntensity: 0.6 }));
  marker.position.z = 0.55;                        // teal hinge ring on the measured joint (outer side)
  elbow.add(marker);

  // ---------------- State / API ----------------
  let side = 'right';
  let skinOn = false;
  let muscleLevel = 0;

  function setMuscle(level) {
    muscleLevel = Math.max(0, Math.min(1, level || 0));
    muscles.forEach((m) => {
      const w = m.w * muscleLevel;
      m.mat.emissive.setRGB(1.0, 0.16, 0.04);
      m.mat.emissiveIntensity = 1.15 * w;            // 0 -> no glow
      m.mat.color.setRGB(1, 1 - 0.30 * w, 1 - 0.34 * w);
      const b = 1 + 0.16 * w;                        // the belly thickens as it contracts
      m.mesh.scale.set(m.sx * b, 1 - 0.03 * w, m.sz * b);
    });
  }

  function setSkin(on) {
    skinOn = !!on;
    skinParts.forEach((p) => { p.visible = skinOn; });
    handMat.color.setHex(skinOn ? SKIN : HAND_MUSCLE);
  }

  function setSide(s) {
    side = s === 'left' ? 'left' : 'right';
    armRoot.scale.z = side === 'left' ? -1 : 1;
  }

  // Same maths as hand_new.py: the angles are absolute (from the start pose), so the forearm
  // angle relative to the upper arm is lower - upper. Positive = forward (flexion).
  function setPose(upperDeg, lowerDeg) {
    const rel = rad(lowerDeg - upperDeg);
    shoulder.rotation.z = rad(upperDeg);
    elbow.rotation.z = rel;
    updateLinks(rel);
  }

  // ---- Camera / controls ----
  const controls = new THREE.OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.dampingFactor = 0.08;
  controls.minDistance = 8;
  controls.maxDistance = 60;
  controls.autoRotate = false;
  controls.autoRotateSpeed = 2.0;

  function goView(name) {
    const s = side === 'left' ? -1 : 1;           // camera on the outer side of the exercising arm
    const cx = 1.3, cy = 3.2, d = 25;
    let p;
    if (name === 'side') p = [cx, cy, s * d];
    else if (name === 'front') p = [cx + d, cy, 0.01];
    else if (name === 'back') p = [cx - d, cy, 0.01];
    else if (name === 'top') p = [cx + 0.01, cy + d, 0.01];
    else p = [cx + d * 0.42, cy + d * 0.18, s * d * 0.85];     // default 3/4 view
    camera.position.set(p[0], p[1], p[2]);
    controls.target.set(cx, cy, 0);
    controls.update();
  }

  function resize() {
    const w = stage.clientWidth, h = stage.clientHeight;
    renderer.setSize(w, h);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }
  window.addEventListener('resize', resize);
  resize();

  function loop() {
    requestAnimationFrame(loop);
    controls.update();
    renderer.render(scene, camera);
  }
  loop();

  setSide('right');
  setSkin(false);
  setMuscle(0);
  setPose(0, 0);
  goView('home');

  return { setSide: setSide, setPose: setPose, setMuscle: setMuscle, setSkin: setSkin, goView: goView, controls: controls, pivot: pivot };
})();
