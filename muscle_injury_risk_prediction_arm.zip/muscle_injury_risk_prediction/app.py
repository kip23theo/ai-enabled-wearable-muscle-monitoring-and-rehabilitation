"""
MUSCLE INJURY RISK PREDICTION

Pages
    /            home page
    /register    create a patient account (sqlite3)
    /login       sign in
    /dashboard   medical tracking, stats and recovery graphs (arm curl)
    /exercise    live 3D arm with muscles + range of motion + live EMG muscle strength
    /risk        muscle injury risk prediction (live from the sensor, or manual input)
    /profile     edit age, muscle density, gender, target ROM
    /report/<id> detail of one saved session

Serial line (one line per reading, 7 numbers):
    forearm x, forearm y, forearm z, biceps x, biceps y, biceps z, EMG (0-4095)
    6 numbers (no EMG) are still accepted.

Risk model (trained separately, same as test.py) - copy these two files into ./models:
    models/best_emg_muscle_risk_model.pkl
    models/model_metadata.pkl
Model inputs: Age, Muscle_Density, Gender (from the registration profile) and EMG (from the sensor).

Run
    pip install -r requirements.txt
    python app.py                 # real sensors on COM4
    python app.py --port COM5     # other serial port
    python app.py --simulate      # no hardware, fake arm curl + EMG

Then open http://127.0.0.1:5000
"""

import argparse
import json
import math
import os
import random
import re
import sqlite3
import threading
import time
from datetime import datetime
from functools import wraps

import numpy as np
from flask import (Flask, abort, flash, g, jsonify, redirect, render_template,
                   request, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

# ============================================
# CONFIGURATION
# ============================================

APP_TITLE = "Muscle Injury Risk Prediction"

SERIAL_PORT = "COM4"
BAUD_RATE = 9600

# Sensor axes. Values 1-3 = forearm, values 4-6 = upper arm (biceps), value 7 = EMG.
BEND_AXIS = 0
GRAVITY_AXIS = 2
CALIBRATION_SAMPLES = 50
ALPHA = 0.3                     # angle smoothing factor (same as hand_new.py)

# EMG muscle strength (0 = relaxed ... 4095 = maximum intensity)
EMG_MAX = 4095
EMG_TAU = 0.15                  # seconds. Time constant of the EMG smoothing filter. It is
                                # TIME based, so the response is the same whatever the sensor's
                                # line rate is. 0 = no smoothing (show the raw value).
EMG_GAP_RESET = 1.0             # seconds without EMG: the filter restarts from the raw value
STALE_AFTER = 1.5               # seconds without any sensor line: values are shown as "no signal"
EMG_LOW_MAX = 1500              # below this: low strength      (same bands as test.py)
EMG_MODERATE_MAX = 2500         # below this: moderate strength, otherwise high

SAMPLE_INTERVAL = 0.2           # seconds between stored samples (5 Hz)
MAX_SAMPLES = 20000             # safety cap per session
MIN_SESSION_SECONDS = 3         # shorter sessions are not saved
REP_UP_DEG = 40                 # a repetition = joint angle goes above this ...
REP_DOWN_DEG = 20               # ... and comes back below this
DEFAULT_TARGET_ROM = 140        # normal elbow flexion is roughly 135-150 degrees

GENDERS = ("Male", "Female")

# Only the arm curl exercise is supported. (The sessions.exercise_type column is kept so
# databases made by older versions still open; it is always 'arm'.)
TYPES = {
    "arm": {"name": "Arm curl", "joint": "Elbow", "lower": "Forearm", "upper": "Upper arm"},
}

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("RISK_DB", os.path.join(BASE_DIR, "muscle_risk.db"))
MODEL_DIR = os.environ.get("MODEL_DIR", os.path.join(BASE_DIR, "models"))
MODEL_PATH = os.path.join(MODEL_DIR, "best_emg_muscle_risk_model.pkl")
METADATA_PATH = os.path.join(MODEL_DIR, "model_metadata.pkl")

app = Flask(__name__)
# Set SECRET_KEY in your environment for real use.
app.secret_key = os.environ.get("SECRET_KEY", "change-this-secret-key")


def emg_band(value):
    """Muscle strength band for an EMG value (thresholds from test.py)."""
    if value is None:
        return None
    if value < EMG_LOW_MAX:
        return "Low strength"
    if value < EMG_MODERATE_MAX:
        return "Moderate strength"
    return "High strength"


# ============================================
# DATABASE (sqlite3)
# ============================================

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    username       TEXT NOT NULL UNIQUE,
    password_hash  TEXT NOT NULL,
    full_name      TEXT NOT NULL,
    age            INTEGER,
    gender         TEXT,
    muscle_density REAL,
    condition      TEXT,
    target_rom     REAL NOT NULL DEFAULT 140,
    created_at     TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    exercise_type TEXT NOT NULL DEFAULT 'arm',
    started_at    TEXT NOT NULL,
    ended_at      TEXT NOT NULL,
    duration_s    REAL NOT NULL,
    elbow_min     REAL NOT NULL,
    elbow_max     REAL NOT NULL,
    elbow_rom     REAL NOT NULL,
    forearm_min   REAL NOT NULL,
    forearm_max   REAL NOT NULL,
    bicep_min     REAL NOT NULL,
    bicep_max     REAL NOT NULL,
    reps          INTEGER NOT NULL DEFAULT 0,
    pain_level    INTEGER NOT NULL DEFAULT 0,
    notes         TEXT,
    emg_avg       REAL,
    emg_max       REAL
);

CREATE TABLE IF NOT EXISTS samples (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    t          REAL NOT NULL,
    bicep      REAL NOT NULL,
    forearm    REAL NOT NULL,
    elbow      REAL NOT NULL,
    emg        REAL
);

CREATE TABLE IF NOT EXISTS predictions (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id        INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at     TEXT NOT NULL,
    source         TEXT NOT NULL,
    age            INTEGER NOT NULL,
    muscle_density REAL NOT NULL,
    gender         TEXT NOT NULL,
    emg            INTEGER NOT NULL,
    band           TEXT,
    risk_class     TEXT NOT NULL,
    scores_json    TEXT
);

CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id, started_at);
CREATE INDEX IF NOT EXISTS idx_samples_session ON samples(session_id, t);
CREATE INDEX IF NOT EXISTS idx_predictions_user ON predictions(user_id, created_at);
"""


def ensure_column(db, table, column, ddl):
    cols = [r[1] for r in db.execute(f"PRAGMA table_info({table})")]
    if column not in cols:                     # database made by an older version
        db.execute(f"ALTER TABLE {table} ADD COLUMN {column} {ddl}")


def init_db():
    with sqlite3.connect(DB_PATH) as db:
        db.executescript(SCHEMA)
        ensure_column(db, "users", "gender", "TEXT")
        ensure_column(db, "users", "muscle_density", "REAL")
        ensure_column(db, "sessions", "exercise_type", "TEXT NOT NULL DEFAULT 'arm'")
        ensure_column(db, "sessions", "emg_avg", "REAL")
        ensure_column(db, "sessions", "emg_max", "REAL")
        ensure_column(db, "samples", "emg", "REAL")


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


# ============================================
# AUTH HELPERS
# ============================================

def current_user():
    uid = session.get("user_id")
    if uid is None:
        return None
    if "user" not in g:
        g.user = get_db().execute(
            "SELECT * FROM users WHERE id = ?", (uid,)).fetchone()
    return g.user


@app.context_processor
def inject_globals():
    return {"current_user": current_user(), "app_title": APP_TITLE}


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if current_user() is None:
            session.clear()
            if request.path.startswith("/api/"):
                return jsonify(ok=False, error="Not signed in."), 401
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)
    return wrapped


@app.template_filter("mmss")
def mmss(seconds):
    s = int(seconds or 0)
    return f"{s // 60}:{s % 60:02d}"


def profile_complete(user):
    try:
        return (user["age"] is not None and 18 <= int(user["age"]) <= 100
                and user["muscle_density"] is not None
                and 0 <= float(user["muscle_density"]) <= 100
                and user["gender"] in GENDERS)
    except (TypeError, ValueError):
        return False


def validate_profile(f):
    """Validate the medical profile form (register + profile pages)."""
    errors = []
    try:
        age = int(f.get("age", "").strip())
        if not 18 <= age <= 100:
            errors.append("Age must be between 18 and 100.")
    except ValueError:
        age = None
        errors.append("Please enter your age as a whole number.")
    try:
        density = float(f.get("muscle_density", "").strip())
        if not 0 <= density <= 100:
            errors.append("Muscle density index must be between 0 and 100.")
    except ValueError:
        density = None
        errors.append("Please enter your muscle density index (0-100).")
    gender = f.get("gender", "").strip().title()
    if gender not in GENDERS:
        errors.append("Please choose Male or Female.")
    try:
        target = float(f.get("target_rom") or DEFAULT_TARGET_ROM)
        if not 30 <= target <= 180:
            errors.append("Target ROM must be between 30 and 180 degrees.")
    except ValueError:
        target = DEFAULT_TARGET_ROM
        errors.append("Target ROM must be a number.")
    clean = {"age": age, "muscle_density": density, "gender": gender,
             "condition": f.get("condition", "").strip()[:120], "target_rom": target}
    return clean, errors


# ============================================
# SHARED SENSOR STATE + EXERCISE SESSION TRACKING
# ============================================

state = {
    "bicep_angle": 0.0,         # upper arm
    "forearm_angle": 0.0,       # forearm
    "elbow_change": 0.0,        # elbow angle = forearm - upper arm
    "emg": None,                # filtered EMG 0-4095: THE value shown, stored and given to the model
    "emg_raw": None,            # last raw EMG reading (shown for reference only)
    "emg_ts": None,             # time.monotonic() of the last EMG reading
    "last_ts": None,            # time.monotonic() of the last sensor line
    "hz": 0.0,                  # sensor lines per second
    "status": "starting",       # starting | calibrating | running | error
    "message": "Starting...",
}
state_lock = threading.Lock()
recalibrate_flag = threading.Event()

exercise = None   # the one active exercise session (dict) or None; guarded by state_lock


def _lo(cur, v):
    return v if cur is None else min(cur, v)


def _hi(cur, v):
    return v if cur is None else max(cur, v)


def new_exercise(user_id, ex_type):
    return {
        "user_id": user_id, "type": ex_type, "started": time.time(), "last_sample": 0.0,
        "e_min": None, "e_max": None, "f_min": None, "f_max": None,
        "b_min": None, "b_max": None,
        "reps": 0, "phase": "down", "samples": [],
        "emg_sum": 0.0, "emg_n": 0, "emg_max": None,
    }


def fresh_emg(now=None):
    """The current filtered EMG, or None when no EMG reading arrived in the last
    STALE_AFTER seconds (so a frozen last value is never shown as if it were live).
    Call with state_lock held."""
    now = time.monotonic() if now is None else now
    if state["emg"] is None or state["emg_ts"] is None or now - state["emg_ts"] > STALE_AFTER:
        return None
    return state["emg"]


def update_sensor(bicep, forearm, emg_raw=None):
    """Called by the sensor/simulation thread for every new reading."""
    now = time.monotonic()
    elbow = forearm - bicep
    with state_lock:
        state["bicep_angle"] = bicep
        state["forearm_angle"] = forearm
        state["elbow_change"] = elbow

        last = state["last_ts"]
        if last is not None and now > last:
            inst = 1.0 / (now - last)
            state["hz"] = inst if state["hz"] == 0 else 0.9 * state["hz"] + 0.1 * inst
        state["last_ts"] = now

        if emg_raw is not None:
            emg_raw = min(max(float(emg_raw), 0.0), float(EMG_MAX))
            prev, prev_ts = state["emg"], state["emg_ts"]
            state["emg_raw"] = emg_raw
            if prev is None or prev_ts is None or now - prev_ts > EMG_GAP_RESET or EMG_TAU <= 0:
                state["emg"] = emg_raw
            else:
                a = 1.0 - math.exp(-(now - prev_ts) / EMG_TAU)     # time-based exponential filter
                state["emg"] = prev + a * (emg_raw - prev)
            state["emg_ts"] = now
        emg = fresh_emg(now)

        ex = exercise
        if ex is None:
            return

        ex["e_min"], ex["e_max"] = _lo(ex["e_min"], elbow), _hi(ex["e_max"], elbow)
        ex["f_min"], ex["f_max"] = _lo(ex["f_min"], forearm), _hi(ex["f_max"], forearm)
        ex["b_min"], ex["b_max"] = _lo(ex["b_min"], bicep), _hi(ex["b_max"], bicep)

        if emg is not None:
            ex["emg_sum"] += emg
            ex["emg_n"] += 1
            ex["emg_max"] = _hi(ex["emg_max"], emg)

        # repetition counter (with hysteresis so noise does not count)
        a = abs(elbow)
        if ex["phase"] == "down" and a >= REP_UP_DEG:
            ex["phase"] = "up"
        elif ex["phase"] == "up" and a <= REP_DOWN_DEG:
            ex["phase"] = "down"
            ex["reps"] += 1

        now = time.time()
        if (now - ex["last_sample"] >= SAMPLE_INTERVAL
                and len(ex["samples"]) < MAX_SAMPLES):
            ex["last_sample"] = now
            ex["samples"].append((round(now - ex["started"], 2), round(bicep, 2),
                                  round(forearm, 2), round(elbow, 2),
                                  None if emg is None else round(emg, 1)))


def set_state(**kwargs):
    with state_lock:
        state.update(kwargs)


def snapshot(ex, uid):
    """Live numbers for the exercise page (call with state_lock held)."""
    if ex is None:
        return None
    if ex["user_id"] != uid:
        return {"mine": False, "type": ex["type"]}
    rom = None if ex["e_min"] is None else ex["e_max"] - ex["e_min"]
    return {
        "mine": True,
        "type": ex["type"],
        "elapsed": time.time() - ex["started"],
        "elbow_min": ex["e_min"], "elbow_max": ex["e_max"], "elbow_rom": rom,
        "forearm_min": ex["f_min"], "forearm_max": ex["f_max"],
        "bicep_min": ex["b_min"], "bicep_max": ex["b_max"],
        "reps": ex["reps"],
        "emg_avg": ex["emg_sum"] / ex["emg_n"] if ex["emg_n"] else None,
        "emg_max": ex["emg_max"],
    }


# ============================================
# SENSOR HELPERS (same logic as hand_new.py, plus the EMG value)
# ============================================

NUMBER_RE = re.compile(r"[-+]?(?:\d*\.)?\d+(?:[eE][-+]?\d+)?")


def read_sensor(ser):
    """Returns (forearm_xyz, upper_arm_xyz, emg) or None.
    Line order: forearm x,y,z, biceps x,y,z, EMG. A line with only 6 numbers is
    accepted too (emg = None)."""
    line = ser.readline().decode("utf-8", errors="ignore").strip()
    if not line:
        return None
    values = NUMBER_RE.findall(line)
    if len(values) not in (6, 7):
        return None
    values = [float(v) for v in values]
    emg = values[6] if len(values) == 7 else None
    return values[0:3], values[3:6], emg


def get_angle(acc):
    return float(np.degrees(np.arctan2(acc[BEND_AXIS], acc[GRAVITY_AXIS])))


def angle_difference(current, reference):
    return (current - reference + 180) % 360 - 180


def circular_mean(values):
    r = np.radians(values)
    return float(np.degrees(np.arctan2(np.mean(np.sin(r)), np.mean(np.cos(r)))))


def sensor_worker(port):
    import serial  # imported here so --simulate works without pyserial

    try:
        ser = serial.Serial(port, BAUD_RATE, timeout=0.02)
    except Exception as exc:
        set_state(status="error", message=f"Cannot open {port}: {exc}")
        return

    time.sleep(2)

    def calibrate():
        """Zero the sensors with the arm straight and still."""
        set_state(status="calibrating", message="Keep the arm straight and still...")
        u_vals, l_vals = [], []
        waiting_since = time.time()
        while len(u_vals) < CALIBRATION_SAMPLES:
            result = read_sensor(ser)
            if result is None:
                if time.time() - waiting_since > 5:
                    set_state(message="No valid sensor data - check the COM port and that "
                                      "each line has 7 numbers (6 sensor values + EMG).")
                continue
            lower, upper, _emg = result
            u_vals.append(get_angle(upper))
            l_vals.append(get_angle(lower))
        set_state(status="running", message="Live")
        return circular_mean(u_vals), circular_mean(l_vals)

    try:
        upper_ref, lower_ref = calibrate()
        upper_angle = lower_angle = 0.0

        while True:
            if recalibrate_flag.is_set():
                recalibrate_flag.clear()
                upper_ref, lower_ref = calibrate()
                upper_angle = lower_angle = 0.0

            result = read_sensor(ser)
            if result is None:
                continue

            lower, upper, emg = result            # forearm, biceps, EMG
            new_upper = angle_difference(get_angle(upper), upper_ref)
            new_lower = angle_difference(get_angle(lower), lower_ref)

            upper_angle = ALPHA * new_upper + (1 - ALPHA) * upper_angle
            lower_angle = ALPHA * new_lower + (1 - ALPHA) * lower_angle

            update_sensor(upper_angle, lower_angle, emg)
    except Exception as exc:
        set_state(status="error", message=f"Sensor error: {exc}")
    finally:
        ser.close()


def simulation_worker():
    """Fake arm curls (angles + noisy EMG) so the app can be tested without hardware."""
    set_state(status="running", message="Simulation mode")
    t0 = time.time()
    while True:
        if recalibrate_flag.is_set():
            recalibrate_flag.clear()
            t0 = time.time()
        t = time.time() - t0
        upper = 20 * math.sin(t * 0.8)
        lower = upper + 70 + 65 * math.sin(t * 1.1)
        level = 0.5 + 0.5 * math.sin(t * 1.1 - 0.6)          # muscle works while bending
        emg = 250 + 3100 * level ** 1.4 + random.uniform(-200, 200)
        update_sensor(upper, lower, max(0.0, min(EMG_MAX, emg)))
        time.sleep(0.02)


# ============================================
# MUSCLE INJURY RISK MODEL (trained separately, see test.py)
# ============================================

class ModelUnavailable(Exception):
    pass


_model_lock = threading.Lock()
_model = {"pipeline": None, "meta": None}


def get_model():
    """Load the saved scikit-learn Pipeline once. Failures are not cached, so you can
    copy the model files into ./models while the app is running."""
    with _model_lock:
        if _model["pipeline"] is not None:
            return _model["pipeline"], _model["meta"]
        for path in (MODEL_PATH, METADATA_PATH):
            if not os.path.isfile(path):
                raise ModelUnavailable(
                    f"Model file not found: models/{os.path.basename(path)}. "
                    "Copy best_emg_muscle_risk_model.pkl and model_metadata.pkl "
                    "into the models folder.")
        try:
            import joblib
            pipeline = joblib.load(MODEL_PATH)
            meta = joblib.load(METADATA_PATH)
        except ImportError:
            raise ModelUnavailable("Missing packages. Run: pip install joblib pandas scikit-learn")
        except Exception as exc:
            raise ModelUnavailable(
                f"Could not load the model ({exc}). Use the same scikit-learn version "
                "that was used to train it.")
        _model["pipeline"], _model["meta"] = pipeline, meta
        return pipeline, meta


def predict_risk(age, muscle_density, gender, emg):
    pipeline, meta = get_model()
    import pandas as pd
    sample = pd.DataFrame([{"Age": age, "Muscle_Density": muscle_density,
                            "Gender": gender, "EMG": emg}])       # same columns as test.py
    try:
        label = str(pipeline.predict(sample)[0])
        scores = []
        if hasattr(pipeline, "predict_proba"):
            probs = pipeline.predict_proba(sample)[0]
            scores = sorted(
                ({"label": str(c), "pct": round(float(p) * 100, 2)}
                 for c, p in zip(pipeline.classes_, probs)),
                key=lambda s: -s["pct"])
    except Exception as exc:
        raise RuntimeError(f"Prediction failed: {exc}")
    classes = ["High_risk", "Moderate_risk", "Low_risk"]
    if hasattr(meta, "get"):
        classes = [str(c) for c in meta.get("target_classes", classes)]
    return {"prediction": label, "scores": scores, "classes": classes}


def parse_risk_inputs(data):
    """Validate the 4 model inputs (ranges as in test.py)."""
    try:
        age = int(float(data.get("age")))
        density = float(data.get("muscle_density"))
        emg = int(round(float(data.get("emg"))))
    except (TypeError, ValueError):
        return None, "Age, muscle density and EMG must be numbers."
    gender = str(data.get("gender", "")).strip().title()
    if not 18 <= age <= 100:
        return None, "Age must be between 18 and 100."
    if not 0 <= density <= 100:
        return None, "Muscle density index must be between 0 and 100."
    if gender not in GENDERS:
        return None, "Gender must be Male or Female."
    if not 0 <= emg <= EMG_MAX:
        return None, f"EMG must be between 0 and {EMG_MAX}."
    return {"age": age, "muscle_density": density, "gender": gender, "emg": emg}, None


def run_prediction(user, inputs, source, save):
    try:
        result = predict_risk(inputs["age"], inputs["muscle_density"],
                              inputs["gender"], inputs["emg"])
    except ModelUnavailable as exc:
        return jsonify(ok=False, code="model", error=str(exc)), 503
    except RuntimeError as exc:
        return jsonify(ok=False, code="predict", error=str(exc)), 500

    band = emg_band(inputs["emg"])
    saved = False
    if save:
        db = get_db()
        db.execute(
            "INSERT INTO predictions (user_id, created_at, source, age, muscle_density, "
            "gender, emg, band, risk_class, scores_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (user["id"], datetime.now().isoformat(timespec="seconds"), source,
             inputs["age"], inputs["muscle_density"], inputs["gender"], inputs["emg"],
             band, result["prediction"], json.dumps(result["scores"])))
        db.commit()
        saved = True
    return jsonify(ok=True, source=source, inputs=inputs, band=band, saved=saved, **result)


# ============================================
# PROGRESS / RECOVERY STATISTICS
# ============================================

def recovery_label(pct):
    if pct < 40:
        return "Early recovery"
    if pct < 70:
        return "Making progress"
    if pct < 90:
        return "Advanced recovery"
    return "Near full range"


def build_progress(db, user, ex_type="arm"):
    rows = db.execute(
        "SELECT * FROM sessions WHERE user_id = ? AND exercise_type = ? "
        "ORDER BY started_at, id", (user["id"], ex_type)).fetchall()

    sessions = []
    for i, r in enumerate(rows, 1):
        sessions.append({
            "id": r["id"], "n": i,
            "date": r["started_at"][:10], "time": r["started_at"][11:16],
            "duration": round(r["duration_s"]),
            "elbow_min": round(r["elbow_min"], 1),
            "elbow_max": round(r["elbow_max"], 1),
            "rom": round(r["elbow_rom"], 1),
            "forearm_min": round(r["forearm_min"], 1),
            "forearm_max": round(r["forearm_max"], 1),
            "bicep_min": round(r["bicep_min"], 1),
            "bicep_max": round(r["bicep_max"], 1),
            "reps": r["reps"], "pain": r["pain_level"], "notes": r["notes"] or "",
            "emg_avg": None if r["emg_avg"] is None else round(r["emg_avg"]),
            "emg_max": None if r["emg_max"] is None else round(r["emg_max"]),
        })

    target = float(user["target_rom"] or DEFAULT_TARGET_ROM)
    summary = {"total": len(sessions), "target": target}

    if sessions:
        roms = [s["rom"] for s in sessions]
        first, latest = roms[0], roms[-1]
        trend = 0.0
        if len(roms) >= 2:
            trend = float(np.polyfit(np.arange(len(roms)), roms, 1)[0])
        recovery = min(100.0, latest / target * 100) if target else 0.0
        eta = None
        if len(roms) >= 3 and trend > 0.05 and latest < target:
            eta = int(math.ceil((target - latest) / trend))
        emg_avgs = [s["emg_avg"] for s in sessions if s["emg_avg"] is not None]
        emg_peaks = [s["emg_max"] for s in sessions if s["emg_max"] is not None]
        summary.update({
            "first_rom": first, "latest_rom": latest, "best_rom": max(roms),
            "change_deg": round(latest - first, 1),
            "change_pct": round((latest - first) / first * 100, 1) if first > 0 else None,
            "recovery_pct": round(recovery, 1),
            "status": recovery_label(recovery),
            "trend": round(trend, 2),
            "eta_sessions": eta,
            "avg_pain": round(sum(s["pain"] for s in sessions) / len(sessions), 1),
            "total_reps": sum(s["reps"] for s in sessions),
            "total_minutes": round(sum(s["duration"] for s in sessions) / 60, 1),
            "last_date": sessions[-1]["date"],
            "emg_latest": emg_avgs[-1] if emg_avgs else None,
            "emg_latest_band": emg_band(emg_avgs[-1]) if emg_avgs else None,
            "emg_peak_best": max(emg_peaks) if emg_peaks else None,
        })

    return {"sessions": sessions, "summary": summary, "target": target,
            "type": ex_type, "labels": TYPES[ex_type]}


# ============================================
# PAGE ROUTES
# ============================================

@app.route("/")
def home():
    return render_template("home.html")


def safe_next(target):
    if target and target.startswith("/") and not target.startswith("//"):
        return target
    return url_for("dashboard")


@app.route("/register", methods=["GET", "POST"])
def register():
    if current_user():
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        f = request.form
        full_name = f.get("full_name", "").strip()
        username = f.get("username", "").strip().lower()
        password = f.get("password", "")
        confirm = f.get("confirm", "")
        clean, errors = validate_profile(f)

        if len(full_name) < 2:
            errors.append("Please enter your full name.")
        if not re.fullmatch(r"[a-z0-9_.-]{3,30}", username):
            errors.append("Username: 3-30 letters, numbers, dot, dash or underscore.")
        if len(password) < 6:
            errors.append("Password must be at least 6 characters.")
        if password != confirm:
            errors.append("Passwords do not match.")

        if not errors:
            db = get_db()
            try:
                cur = db.execute(
                    "INSERT INTO users (username, password_hash, full_name, age, gender, "
                    "muscle_density, condition, target_rom, created_at) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (username, generate_password_hash(password), full_name, clean["age"],
                     clean["gender"], clean["muscle_density"], clean["condition"],
                     clean["target_rom"], datetime.now().isoformat(timespec="seconds")))
                db.commit()
            except sqlite3.IntegrityError:
                errors.append("That username is already taken.")
            else:
                session.clear()
                session["user_id"] = cur.lastrowid
                flash("Account created. Welcome!", "ok")
                return redirect(url_for("dashboard"))

        for e in errors:
            flash(e, "error")

    return render_template("register.html", form=request.form,
                           default_target=DEFAULT_TARGET_ROM)


@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user():
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip().lower()
        password = request.form.get("password", "")
        user = get_db().execute(
            "SELECT * FROM users WHERE username = ?", (username,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            return redirect(safe_next(request.args.get("next")))
        flash("Wrong username or password.", "error")

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been signed out.", "ok")
    return redirect(url_for("home"))


@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    user = current_user()
    if request.method == "POST":
        full_name = request.form.get("full_name", "").strip()
        clean, errors = validate_profile(request.form)
        if len(full_name) < 2:
            errors.append("Please enter your full name.")
        if not errors:
            db = get_db()
            db.execute(
                "UPDATE users SET full_name = ?, age = ?, gender = ?, muscle_density = ?, "
                "condition = ?, target_rom = ? WHERE id = ?",
                (full_name, clean["age"], clean["gender"], clean["muscle_density"],
                 clean["condition"], clean["target_rom"], user["id"]))
            db.commit()
            flash("Profile updated.", "ok")
            return redirect(url_for("risk_page"))
        for e in errors:
            flash(e, "error")
        form = request.form
    else:
        form = {"full_name": user["full_name"], "age": user["age"] or "",
                "gender": user["gender"] or "", "muscle_density": user["muscle_density"]
                if user["muscle_density"] is not None else "",
                "condition": user["condition"] or "", "target_rom": user["target_rom"]}
    return render_template("profile.html", form=form)


@app.route("/dashboard")
@login_required
def dashboard():
    user = current_user()
    db = get_db()
    ex_type = "arm"
    progress = build_progress(db, user, ex_type)
    return render_template("dashboard.html", user=user, progress=progress,
                           summary=progress["summary"],
                           history=list(reversed(progress["sessions"])),
                           ex_type=ex_type, labels=TYPES[ex_type],
                           rep_up=REP_UP_DEG, rep_down=REP_DOWN_DEG,
                           emg_low=EMG_LOW_MAX, emg_mod=EMG_MODERATE_MAX)


@app.route("/exercise")
@login_required
def exercise_page():
    user = current_user()
    return render_template("exercise.html", user=user, labels=TYPES["arm"],
                           target=float(user["target_rom"] or DEFAULT_TARGET_ROM),
                           emg_low=EMG_LOW_MAX, emg_mod=EMG_MODERATE_MAX, emg_max=EMG_MAX)


@app.route("/risk")
@login_required
def risk_page():
    user = current_user()
    model_error = None
    classes = ["High_risk", "Moderate_risk", "Low_risk"]
    try:
        _pipeline, meta = get_model()
        if hasattr(meta, "get"):
            classes = [str(c) for c in meta.get("target_classes", classes)]
    except ModelUnavailable as exc:
        model_error = str(exc)
    return render_template("risk.html", user=user, complete=profile_complete(user),
                           model_error=model_error, classes=classes,
                           emg_low=EMG_LOW_MAX, emg_mod=EMG_MODERATE_MAX, emg_max=EMG_MAX)


@app.route("/report/<int:sid>")
@login_required
def report(sid):
    user = current_user()
    db = get_db()
    row = db.execute("SELECT id FROM sessions WHERE id = ? AND user_id = ? "
                     "AND exercise_type = 'arm'", (sid, user["id"])).fetchone()
    if row is None:
        abort(404)
    ex_type = "arm"
    progress = build_progress(db, user, ex_type)
    this = next((s for s in progress["sessions"] if s["id"] == sid), None)
    if this is None:
        abort(404)
    prev = next((s for s in progress["sessions"] if s["n"] == this["n"] - 1), None)
    samples = [[r["t"], r["bicep"], r["forearm"], r["elbow"], r["emg"]] for r in db.execute(
        "SELECT t, bicep, forearm, elbow, emg FROM samples WHERE session_id = ? ORDER BY t",
        (sid,))]
    return render_template("report.html", s=this, prev=prev, samples=samples,
                           target=progress["target"], user=user,
                           ex_type=ex_type, labels=TYPES[ex_type],
                           has_emg=any(r[4] is not None for r in samples),
                           emg_low=EMG_LOW_MAX, emg_mod=EMG_MODERATE_MAX)


# ============================================
# LIVE / SESSION API
# ============================================

@app.route("/api/angles")
@login_required
def api_angles():
    uid = session["user_id"]
    now = time.monotonic()
    with state_lock:
        data = dict(state)
        data["session"] = snapshot(exercise, uid)
        emg = fresh_emg(now)
        age = None if state["last_ts"] is None else now - state["last_ts"]
    # One canonical EMG value: what the page shows, what is stored in the session and
    # what the risk model receives. None = no EMG arriving (never a frozen old value).
    data["emg"] = emg
    data["emg_raw"] = data["emg_raw"] if emg is not None else None
    data["emg_band"] = emg_band(emg)
    data["sensor_age"] = age
    data["stale"] = data["status"] == "running" and (age is None or age > STALE_AFTER)
    if data["stale"] and age is not None:
        data["message"] = f"No data from the sensor for {age:.0f} s. Check the cable and COM port."
    for k in ("emg_ts", "last_ts"):
        data.pop(k, None)
    return jsonify(data)


@app.route("/api/recalibrate", methods=["POST"])
@login_required
def api_recalibrate():
    with state_lock:
        if exercise is not None:
            return jsonify(ok=False, error="Finish the session before recalibrating."), 409
    recalibrate_flag.set()
    return jsonify(ok=True)


@app.route("/api/session/start", methods=["POST"])
@login_required
def api_session_start():
    global exercise
    uid = session["user_id"]
    with state_lock:
        if exercise is not None:
            return jsonify(ok=False, error="A session is already in progress."), 409
        if state["status"] != "running":
            return jsonify(ok=False, error="Sensors are not ready yet."), 400
        exercise = new_exercise(uid, "arm")
    return jsonify(ok=True)


@app.route("/api/session/discard", methods=["POST"])
@login_required
def api_session_discard():
    global exercise
    uid = session["user_id"]
    with state_lock:
        if exercise is not None and exercise["user_id"] == uid:
            exercise = None
    return jsonify(ok=True)


@app.route("/api/session/end", methods=["POST"])
@login_required
def api_session_end():
    global exercise
    uid = session["user_id"]
    data = request.get_json(silent=True) or {}
    try:
        pain = max(0, min(10, int(data.get("pain", 0))))
    except (TypeError, ValueError):
        pain = 0
    notes = str(data.get("notes", ""))[:500].strip()

    db = get_db()
    with state_lock:
        ex = exercise
        if ex is None or ex["user_id"] != uid:
            return jsonify(ok=False, error="No active session."), 404

        duration = time.time() - ex["started"]
        if duration < MIN_SESSION_SECONDS or ex["e_min"] is None:
            return jsonify(ok=False, error="Session too short - keep moving "
                           "your limb a little longer, or discard it."), 400

        started = datetime.fromtimestamp(ex["started"]).isoformat(timespec="seconds")
        ended = datetime.now().isoformat(timespec="seconds")
        emg_avg = ex["emg_sum"] / ex["emg_n"] if ex["emg_n"] else None
        try:
            cur = db.execute(
                "INSERT INTO sessions (user_id, exercise_type, started_at, ended_at, "
                "duration_s, elbow_min, elbow_max, elbow_rom, forearm_min, "
                "forearm_max, bicep_min, bicep_max, reps, pain_level, notes, "
                "emg_avg, emg_max) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (uid, ex["type"], started, ended, round(duration, 1),
                 ex["e_min"], ex["e_max"], ex["e_max"] - ex["e_min"],
                 ex["f_min"], ex["f_max"], ex["b_min"], ex["b_max"],
                 ex["reps"], pain, notes, emg_avg, ex["emg_max"]))
            sid = cur.lastrowid
            db.executemany(
                "INSERT INTO samples (session_id, t, bicep, forearm, elbow, emg) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                [(sid, *s) for s in ex["samples"]])
            db.commit()
        except sqlite3.Error as exc:
            db.rollback()
            return jsonify(ok=False, error=f"Could not save session: {exc}"), 500
        exercise = None          # only cleared once the data is safely stored

    progress = build_progress(db, current_user(), ex["type"])
    this = next(s for s in progress["sessions"] if s["id"] == sid)
    return jsonify(ok=True, id=sid, session=this, progress=progress)


# ============================================
# RISK PREDICTION API
# ============================================

@app.route("/api/predict", methods=["POST"])
@login_required
def api_predict_manual():
    """Manual prediction from the 4 values typed by the user (always saved to the log)."""
    inputs, error = parse_risk_inputs(request.get_json(silent=True) or {})
    if error:
        return jsonify(ok=False, code="input", error=error), 400
    return run_prediction(current_user(), inputs, "manual", save=True)


@app.route("/api/predict/live", methods=["POST"])
@login_required
def api_predict_live():
    """Live prediction: Age / Muscle density / Gender from the profile, EMG from the sensor."""
    user = current_user()
    data = request.get_json(silent=True) or {}
    if not profile_complete(user):
        return jsonify(ok=False, code="profile",
                       error="Complete your profile (age, muscle density, gender) first."), 400
    with state_lock:
        emg, status, message = fresh_emg(), state["status"], state["message"]
        sensor_silent = state["last_ts"] is None or time.monotonic() - state["last_ts"] > STALE_AFTER
    if status != "running":
        return jsonify(ok=False, code="sensor", error=message or "Sensors are not ready yet."), 409
    if sensor_silent:
        return jsonify(ok=False, code="sensor",
                       error="No data from the sensor. Check the cable and COM port."), 409
    if emg is None:
        return jsonify(ok=False, code="no_emg",
                       error="No EMG value received. Each serial line needs 7 numbers "
                             "(the 7th is the EMG)."), 409
    inputs, error = parse_risk_inputs({
        "age": user["age"], "muscle_density": user["muscle_density"],
        "gender": user["gender"], "emg": emg})
    if error:
        return jsonify(ok=False, code="input", error=error), 400
    return run_prediction(user, inputs, "live", save=bool(data.get("save")))


@app.route("/api/predictions")
@login_required
def api_predictions():
    rows = get_db().execute(
        "SELECT * FROM predictions WHERE user_id = ? ORDER BY created_at DESC, id DESC LIMIT 15",
        (session["user_id"],)).fetchall()
    out = []
    for r in rows:
        try:
            scores = json.loads(r["scores_json"] or "[]")
        except ValueError:
            scores = []
        out.append({"id": r["id"], "created_at": r["created_at"], "source": r["source"],
                    "age": r["age"], "muscle_density": r["muscle_density"],
                    "gender": r["gender"], "emg": r["emg"], "band": r["band"],
                    "risk_class": r["risk_class"],
                    "top_pct": scores[0]["pct"] if scores else None})
    return jsonify(ok=True, predictions=out)


# ============================================
# MAIN
# ============================================

init_db()

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", default=SERIAL_PORT)
    parser.add_argument("--simulate", action="store_true")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--web-port", type=int, default=5000)
    args = parser.parse_args()

    target_fn = simulation_worker if args.simulate else sensor_worker
    worker_args = () if args.simulate else (args.port,)
    threading.Thread(target=target_fn, args=worker_args, daemon=True).start()

    # debug=False / no reloader: the reloader would open the COM port twice
    app.run(host=args.host, port=args.web_port, debug=False, threaded=True)
