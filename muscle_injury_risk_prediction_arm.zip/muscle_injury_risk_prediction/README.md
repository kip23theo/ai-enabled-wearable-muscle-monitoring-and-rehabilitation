# MUSCLE INJURY RISK PREDICTION

Flask app for the ARM CURL exercise. It shows a live 3D arm with its muscles (the biceps
glows and thickens with the EMG muscle strength), records exercise sessions, and predicts
muscle injury risk with your machine-learning model (live from the sensor, or from values
you type).

## Setup
    pip install -r requirements.txt
    # copy your two model files (the ones test.py uses) into the models/ folder:
    #   models/best_emg_muscle_risk_model.pkl
    #   models/model_metadata.pkl

Use the same scikit-learn version that trained the model.

## Run
    python app.py                 # real sensors on COM4
    python app.py --port COM5     # other serial port
    python app.py --simulate      # no hardware: fake arm curls + fake EMG

Open http://127.0.0.1:5000   (internet is needed once for the three.js / Chart.js CDN files)

## Serial format (one line per reading, 7 numbers)
    forearm x, forearm y, forearm z, biceps x, biceps y, biceps z, EMG
    e.g.  0.12, -0.35, 12.24, 0.24, -0.71, 8.43, 101
- EMG is 0-4095: 0 = relaxed muscle, 4095 = maximum muscle intensity.
- A line with only 6 numbers (no EMG) still works; EMG features then show "No EMG data".
- The raw EMG is noisy, so the app filters it with a short TIME-based filter (EMG_TAU = 0.15 s
  in app.py; it behaves the same whatever your sensor's line rate). This filtered value is the
  ONE EMG value used everywhere: the number on screen, the band, the meter, the graph, the
  glowing biceps, the saved session average/peak and the input of the risk model. The raw
  reading is shown next to it for reference. Set EMG_TAU = 0 to use the raw value only.
- If no sensor line arrives for 1.5 s (STALE_AFTER) the pages show "No signal" instead of a
  frozen old value, and the risk page does not predict from stale data.

## EMG muscle strength bands (same as test.py)
    EMG < 1500   Low strength
    EMG < 2500   Moderate strength
    otherwise    High strength

## Pages
- Home, Register / Login (sqlite3)
- Exercise: 3D arm with muscles, bones and tendons (right or left arm, Skin on/off),
  live EMG value, band, meter and graph; the biceps glows red and thickens as EMG rises
  (the glow follows the same Low / Moderate / High bands as the chip); range of motion;
  repetitions; sessions are saved.
- Risk prediction (nav link):
    * Live from sensor: Age, Muscle density and Gender come from your profile, EMG from
      the sensor. The live EMG number updates about 7 times a second on its own; the
      prediction refreshes about twice a second and shows which EMG it used.
      "Save this reading" logs it.
    * Manual input: type Age, Muscle density, Gender and EMG (or "Use current sensor EMG")
      and press Predict. Manual predictions are saved to your log.
- Dashboard: ROM graphs, pain, repetitions and EMG strength per arm curl session.
- Profile: edit age, muscle density, gender, target ROM.

## Model inputs (as in test.py)
    Age (18-100), Muscle_Density (0-100), Gender (Male/Female) -> from registration/profile
    EMG (0-4095)                                                -> from the sensor
The page shows the predicted class (e.g. High_risk / Moderate_risk / Low_risk) and the
class scores from predict_proba.

NOTE: as in test.py, the model was trained on synthetic data and is not a clinically
validated injury diagnosis or risk assessment tool.

## Files
    app.py                  Flask server, sqlite3 database, serial reader, EMG, model loading
    muscle_risk.db          created automatically on first run
    models/                 put the two .pkl model files here
    templates/              home, login, register, profile, dashboard, exercise, risk, report
    static/style.css        shared styles
    static/js/arm3d.js      3D arm with muscles, bones and tendons (muscle glow from EMG)
    static/js/charts.js     graphs (Chart.js)

## Tuning (top of app.py)
- SERIAL_PORT, ALPHA, BEND_AXIS, GRAVITY_AXIS: same meaning as in hand_new.py
- EMG_TAU (EMG smoothing, seconds), STALE_AFTER, EMG_LOW_MAX / EMG_MODERATE_MAX (strength bands)
- REP_UP_DEG / REP_DOWN_DEG, MIN_SESSION_SECONDS, DEFAULT_TARGET_ROM
- SECRET_KEY: set as an environment variable before real use

## Notes on this version
- Arm curl only: the leg exercise, the full body and the face-down pose were removed. Sessions
  saved earlier as "leg" stay in the database file but are not shown.
- Environment variables (optional): SECRET_KEY, MODEL_DIR (folder with the two .pkl files),
  RISK_DB (path of the sqlite file).
