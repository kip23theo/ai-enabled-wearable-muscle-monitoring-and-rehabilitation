Put your two trained model files in this folder (the ones test.py loads):

    best_emg_muscle_risk_model.pkl
    model_metadata.pkl

They can be copied while the app is running; the Risk prediction page picks them up
on the next prediction. Install the SAME scikit-learn version that was used to train
the model (check it in your notebook with: import sklearn; print(sklearn.__version__)).
